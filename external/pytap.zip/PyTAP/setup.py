
from distutils.core import setup

setup(
  name    = "pyTAP",
  version = "0.001",
  py_modules = [ "TAP.Simple" ],
)
